<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('locations', function (Blueprint $table) {
         $table->decimal('lat_min', 5, 2)->nullable()->after('polygon');
            $table->decimal('lat_max', 5, 2)->nullable()->after('lat_min');
            $table->decimal('lon_min', 6, 2)->nullable()->after('lat_max');
            $table->decimal('lon_max', 6, 2)->nullable()->after('lon_min');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('locations', function (Blueprint $table) {
            //
        });
    }
};
